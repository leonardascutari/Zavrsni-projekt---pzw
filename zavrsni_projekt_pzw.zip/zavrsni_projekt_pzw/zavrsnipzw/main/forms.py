from django import forms
from .models import Rezultat, Raspored, Termin

class RezultatForm(forms.ModelForm):
    class Meta:
        model = Rezultat
        fields = '__all__'

class RasporedForm(forms.ModelForm):
    class Meta:
        model = Raspored
        fields = '__all__'

class TerminForm(forms.ModelForm):
    class Meta:
        model = Termin
        fields = '__all__'
